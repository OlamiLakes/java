package Assigments;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

class Bank {
    private List<Account> accounts;

    public Bank() {
        accounts = new ArrayList<>();
    }

    public void addAccount(Account account) {
        accounts.add(account);
    }

    public void removeAccount(Account account) {
        accounts.remove(account);
    }

    public void displayAllAccounts() {
        for (Account account : accounts) {
            System.out.println(account);
        }
    }

    public Account getAccountByNumber(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        return null;
    }
}

class Account {
    private String accountNumber;
    private String accountHolder;
    private double balance;

    public Account(String accountNumber, String accountHolder, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + " to account " + accountNumber);
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn " + amount + " from account " + accountNumber);
        } else {
            System.out.println("Insufficient balance in account " + accountNumber);
        }
    }

    @Override
    public String toString() {
        return "Account Number: " + accountNumber + ", Account Holder: " + accountHolder + ", Balance: " + balance;
    }
}

public class BankingSystem {
    public static void main(String[] args) {
        Bank bank = new Bank();

        Account acc1 = new Account("001", "John Doe", 1000);
        Account acc2 = new Account("002", "Jane Smith", 5000);

        bank.addAccount(acc1);
        bank.addAccount(acc2);

        bank.displayAllAccounts();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose an option:");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Create Account");

        int option = scanner.nextInt();

        switch (option) {
            case 1:
                System.out.print("Enter account number: ");
                String checkAccountNumber = scanner.next();
                Account checkAccount = bank.getAccountByNumber(checkAccountNumber);
                if (checkAccount != null) {
                    System.out.println("Account balance: " + checkAccount.getBalance());
                } else {
                    System.out.println("Account not found!");
                }
                break;
            case 2:
                System.out.print("Enter account number: ");
                String depositAccountNumber = scanner.next();
                Account depositAccount = bank.getAccountByNumber(depositAccountNumber);
                if (depositAccount != null) {
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    depositAccount.deposit(depositAmount);
                } else {
                    System.out.println("Account not found!");
                }
                break;
            case 3:
                System.out.print("Enter account number: ");
                String withdrawAccountNumber = scanner.next();
                Account withdrawAccount = bank.getAccountByNumber(withdrawAccountNumber);
                if (withdrawAccount != null) {
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    withdrawAccount.withdraw(withdrawAmount);
                } else {
                    System.out.println("Account not found!");
                }
                break;
            case 4:
                System.out.print("Enter account holder name: ");
                String accountHolder = scanner.next();
                System.out.print("Enter initial balance: ");
                double initialBalance = scanner.nextDouble();

                String accountNumber = generateAccountNumber();
                Account newAccount = new Account(accountNumber, accountHolder, initialBalance);
                bank.addAccount(newAccount);
                System.out.println("New account created: " + newAccount);
                break;
            default:
                System.out.println("Invalid option selected.");
                break;
        }
    }

    private static String generateAccountNumber() {
        Random random = new Random();
        StringBuilder accountNumber = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            int digit = random.nextInt(10);
            accountNumber.append(digit);
        }
        return accountNumber.toString();
    }
}