// An error in Java represents a severe issue that generally indicates a problem outside the control of the application. Errors are typically caused by critical system failures, such as out-of-memory conditions or stack overflow, and are often irrecoverable

package Assigments.ErrorAndExceptions;

public class StackOverflowExample {
    public static void recursiveMethod() {
        recursiveMethod();
    }

    public static void main(String[] args) {
        recursiveMethod();
    }
}