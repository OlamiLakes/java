// Exceptions in Java represent exceptional events or conditions that can occur during the normal execution of a program. Exceptions can be caused by various factors, such as invalid input, network issues, file I/O errors, or arithmetic errors.

package Assigments.ErrorAndExceptions;

public class ExceptionHandlingExample {
    public static void main(String[] args) {
        int a = 10;
        int b = 0;

        try {
            int result = a / b;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero");
        }
    }
}