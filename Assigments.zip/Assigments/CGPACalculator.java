package Assigments;
import java.util.Scanner;

public class CGPACalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of subjects: ");
        int numSubjects = scanner.nextInt();

        double[] grades = new double[numSubjects];
        int[] creditHours = new int[numSubjects];

        // Input grades and credit hours for each subject
        for (int i = 0; i < numSubjects; i++) {
            System.out.print("Enter the grade for subject " + (i + 1) + ": ");
            grades[i] = scanner.nextDouble();

            System.out.print("Enter the credit hours for subject " + (i + 1) + ": ");
            creditHours[i] = scanner.nextInt();
        }

        double totalCreditPoints = 0;
        int totalCreditHours = 0;

        // Calculate total credit points and credit hours
        for (int i = 0; i < numSubjects; i++) {
            totalCreditPoints += grades[i] * creditHours[i];
            totalCreditHours += creditHours[i];
        }

        double cgpa = totalCreditPoints / totalCreditHours;

        System.out.println("Your CGPA is: " + cgpa);

        scanner.close();
    }
}
